//
//  ViewController.swift
//  CustomCamera
//
//  Created by OPTLPTP250 on 24/05/19.
//  Copyright © 2019 Divesh Singh. All rights reserved.
//

import UIKit
import AVFoundation

@available(iOS 11.0, *)
class ViewController: UIViewController,AVCapturePhotoCaptureDelegate {

    var captureSession: AVCaptureSession!
    var stillImageOutput: AVCapturePhotoOutput!
    var videoPreviewLayer: AVCaptureVideoPreviewLayer!
    @IBOutlet weak var previewLayer: UIView!
    @IBOutlet weak var imageView: UIImageView!

    @IBOutlet weak var camerabutton: UIButton!

    override func viewWillDisappear(_ animated: Bool) {
        super.viewWillDisappear(animated)
        self.captureSession.stopRunning()
    }

    override func viewDidLayoutSubviews() {

        if let previewLayer = videoPreviewLayer ,(previewLayer.connection?.isVideoOrientationSupported)! {
            DispatchQueue.main.async {
                self.videoPreviewLayer.frame = self.previewLayer.layer.bounds
            }
            previewLayer.connection?.videoOrientation = UIApplication.shared.statusBarOrientation.videoOrientation ?? .portrait
        }
    }


    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
        // Setup your camera here...
        captureSession = AVCaptureSession()
        captureSession.sessionPreset = .medium

        guard let backCamera = AVCaptureDevice.default(for: AVMediaType.video)
            else {
                print("Unable to access back camera!")
                return
        }

        do {
            let input = try AVCaptureDeviceInput(device: backCamera)
            //Step 9

            stillImageOutput = AVCapturePhotoOutput()

            if captureSession.canAddInput(input) && captureSession.canAddOutput(stillImageOutput) {
                captureSession.addInput(input)
                captureSession.addOutput(stillImageOutput)
                setupLivePreview()
            }
        }
        catch let error  {
            print("Error Unable to initialize back camera:  \(error.localizedDescription)")
        }
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        switch AVCaptureDevice.authorizationStatus(for: .video) {
        case .authorized:
            // The user has previously granted access to the camera.
            break
        case .notDetermined:
            AVCaptureDevice.requestAccess(for: .video, completionHandler: { granted in
            })
        default: break
            // The user has previously denied access.
        }
        // Do any additional setup after loading the view, typically from a nib.
    }

    @IBAction func buttonaction(_ sender: Any) {
        // Get an instance of AVCapturePhotoSettings class
        let photoSettings = AVCapturePhotoSettings()

        // Set photo settings for our need
        photoSettings.isAutoStillImageStabilizationEnabled = true
        photoSettings.isHighResolutionPhotoEnabled = false
        photoSettings.flashMode = .off

        stillImageOutput.capturePhoto(with: photoSettings, delegate: self)
    }

    func photoOutput(_ captureOutput: AVCapturePhotoOutput,
                     didFinishProcessingPhoto photoSampleBuffer: CMSampleBuffer?,
                     previewPhoto previewPhotoSampleBuffer: CMSampleBuffer?,
                     resolvedSettings: AVCaptureResolvedPhotoSettings,
                     bracketSettings: AVCaptureBracketedStillImageSettings?,
                     error: Error?) {
        // Make sure we get some photo sample buffer
        guard error == nil,
            let photoSampleBuffer = photoSampleBuffer else {
                print("Error capturing photo: \(String(describing: error))")
                return
        }

        // Convert photo same buffer to a jpeg image data by using AVCapturePhotoOutput
        guard let imageData = AVCapturePhotoOutput.jpegPhotoDataRepresentation(forJPEGSampleBuffer: photoSampleBuffer, previewPhotoSampleBuffer: previewPhotoSampleBuffer) else {
            return
        }

        // Initialise an UIImage with our image data
        let capturedImage = UIImage.init(data: imageData , scale: 1.0)

        var image = UIImage()
        let or =    UIApplication.shared.statusBarOrientation
        switch or {
        case .landscapeLeft:
            image = UIImage(cgImage: (capturedImage?.cgImage!)!, scale: (capturedImage?.scale)!, orientation: .down)
        case .landscapeRight:
            image = UIImage(cgImage: (capturedImage?.cgImage!)!, scale: (capturedImage?.scale)!, orientation: .up)
        case .portraitUpsideDown:
            image = UIImage(cgImage: (capturedImage?.cgImage!)!, scale: (capturedImage?.scale)!, orientation: .left)
        case .portrait:
            image = UIImage(cgImage: (capturedImage?.cgImage!)!, scale: (capturedImage?.scale)!, orientation: .right)
        default:
            image = UIImage(cgImage: (capturedImage?.cgImage!)!, scale: (capturedImage?.scale)!, orientation: .up)
        }
        // Save our captured image to photos album
        self.imageView.image = image
        UIImageWriteToSavedPhotosAlbum(image, nil, nil, nil)
    }


    func setupLivePreview() {

        videoPreviewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
        videoPreviewLayer.videoGravity = .resize
        videoPreviewLayer.connection?.videoOrientation = UIApplication.shared.statusBarOrientation.videoOrientation ?? .portrait
        previewLayer.layer.addSublayer(videoPreviewLayer)

        DispatchQueue.global(qos: .userInitiated).async { //[weak self] in
            self.captureSession.startRunning()
            //Step 13
            DispatchQueue.main.async {

                print(self.videoPreviewLayer.frame)
                print(self.previewLayer.frame)

                self.videoPreviewLayer.frame = self.previewLayer.layer.bounds


            }
        }    }
}



//    func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
//
//        guard let imageData = photo.fileDataRepresentation()
//            else { return }
//
//        let image = UIImage(data: imageData)
//        imageView.image = image
//    }
//
//    func metadataOutput(_ captureOutput: AVCaptureMetadataOutput,
//                        didOutput metadataObjects: [AVMetadataObject],
//                        from connection: AVCaptureConnection) {
//        // Check if the metadataObjects array is contains at least one object.
//        if metadataObjects.count == 0 {
//            return
//        }
//
//        // Get the metadata object.
//        let metadataObj = metadataObjects[0] as! AVMetadataMachineReadableCodeObject
//
//        if metadataObj.type == AVMetadataObject.ObjectType.qr {
//            // If the found metadata is equal to the QR code metadata then update the status label's text and set the bounds
//            let barCodeObject = videoPreviewLayer?.transformedMetadataObject(for: metadataObj)
////            qrCodeFrameView?.frame = barCodeObject!.bounds
//
//            if metadataObj.stringValue != nil {
////                messageLabel.isHidden = false
////                messageLabel.text = metadataObj.stringValue
//            }
//        }
//    }



