//
//  Ext.UIInterfaceOrientation.swift
//  CustomCamera
//
//  Created by OPTLPTP250 on 26/05/19.
//  Copyright © 2019 Divesh Singh. All rights reserved.
//

import Foundation
import AVFoundation
import UIKit

public extension UIInterfaceOrientation {
    var videoOrientation: AVCaptureVideoOrientation? {
        switch self {
        case .portraitUpsideDown: return .portraitUpsideDown
        case .landscapeRight: return .landscapeRight
        case .landscapeLeft: return .landscapeLeft
        case .portrait: return .portrait
        default: return nil
        }
    }
}
